import React from 'react';
import { Route, Routes } from 'react-router-dom';
import HomePage from './pages/Home/HomePage';
import ProductPage from './pages/Product/ProductPage';
import Cart from './pages/Cart/Cart';

export default function AppRoutes() {
  return (
    <Routes>
        <Route path="/HomePage" element={<HomePage/>}/>
        <Route path="/search/:searchTerm" element={<HomePage/>}/>
        <Route path="/tag/:tag" element={<HomePage/>}/>
        <Route path="/food/:id" element={<ProductPage/>}/>
        <Route path="/cart" element={<Cart/>}/>
    </Routes>
  );
}
