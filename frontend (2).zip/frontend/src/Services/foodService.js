import { Cakes,sample_tags } from "../Data";

export const getAll = async()=>Cakes;

export const search = async searchTerm =>
    Cakes.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

export const getAllTags = async () => sample_tags;

export const getAllByTag=async tag =>{
    if (tag === 'All')return getAll();
    return Cakes.filter(item=>item.tags?.includes(tag));
};

export const getById=async foodId =>
    Cakes.find(item => item.id === foodId);