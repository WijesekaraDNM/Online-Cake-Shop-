import React from 'react';
import classes from './homePage.module.css';

export default function HomePage() {
  return (
        <div className={classes.k}>
            <div className={classes.bg}>
        
                <div className={classes.about}>
                    <div>
                        Marvelous & Delicious Cakes for Everyone
                    </div>
                     <div>
                        <button className={classes.button}> See More</button>
                    </div>
           
                </div>
                 <div className={classes.circle}>   
                    <img className={classes.image2} src={"/foods/Piece.png"} alt=""/>
                </div>
            </div>
            <div className={classes.info}>
                <div>
                    food
                </div>
            </div>
        </div>
        
       


  );

};

