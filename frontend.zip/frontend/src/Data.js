export const Cakes=[
    {
        id:'1',
        name:'Birthday Cakes',
        price: 2000,
        imageUrl:'cake-6.png',
        tags:['Birthday Cakes'],
    },
    {
        id:'2',
        name:'Wedding Cakes',
        price:25000,
        imageUrl:'cake16.jpg',
        tags:['Wedding Cakes'],
    },
    {
        id:'3',
        name:'Gateaux',
        price:5600,
        imageUrl:'cake-9.jpg',
        tags:['Gateaux'],
    },
    {
        id:'4',
        name:'Cup Cakes',
        price:2000,
        imageUrl:'cake-13.jpg',
        tags:['Cup Cakes'],
    },
];

export const sample_tags = [
    {name: 'All', count:4},
    {name: 'Birthday Cakes', count:1},
    {name: 'Wedding Cakes', count:1},
    {name: 'Gateaux', count:1},
    {name: 'Cup Cakes',count:1},
];