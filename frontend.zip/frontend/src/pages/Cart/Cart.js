import React from 'react';
import classes from './cartPage.module.css';
export default function Cart() {
    const {cart}= useCart();
  return <div>Cart</div>;
  
}
